# PrivateIsle (eu.hypixel.net) World Save - Snapshot Details
![Server Icon](../icon.png)

- **Time**: `Thu, 2 Jan 2025 10:44:07 +0100` (Timestamp: `1735811047356`)
- **Captured By**: `CarsCupcake`

## Server
- **IP**: `eu.hypixel.net`
- **Capacity**: `22432/200000`
- **Brand**: `Hypixel BungeeCord (2024.12.28.2) <- Hygot 2024.12.11.1`
- **MOTD**: `                §aHypixel Network §c[1.8-1.21] §l§c§lHOLIDAY EVENT§7 | §6§lDISASTERS §7| §d§lMOUNTAINTOP `
- **Version**: `Requires MC 1.8 / 1.21`
- **Protocol Version**: `767`
- **Server Type**: `OTHER`

## Connection
- **Host Name**: `209.222.115.78`
- **Port**: `25565`

This file was created by [WorldTools 1.2.6](https://github.com/Avanatiker/WorldTools/)
